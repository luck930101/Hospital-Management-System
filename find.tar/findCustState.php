 <?php

include('connectionData.txt');

try 
{	
	$dbh = new PDO('mysql:host='.$server.';port='.$port.';dbname='.$dbname, $user, $pass);
} catch (PDOException $e) {
	print $e->getMessage();
 	exit;
} 

?>

<html>
<head>
  <title>Another Simple PHP-MySQL Program</title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
  
$state = $_POST['state'];

$query = "SELECT DISTINCT firstName, lastName FROM customer WHERE state = ";
$query = $query."'".$state."' ORDER BY 2;";

?>

<p>
The query:
<p>
<?php
print $query;
?>

<hr>
<p>
Result of query:
<p>

<?php

$result = $dbh->query($query);

if (!$result) 
{
	print "execution error: </br>";
	$error = $dbh->errorInfo();
    print($error[2]);
    exit;
}

      
print "<pre>";

while($row = $result->fetch())
{
    print "\n";
    print "$row[firstName] $row[lastName]";
}
print "</pre>";

$dbh = null;

?>

<p>
<hr>

<p>
<a href="findCustState.txt" >Contents</a>
of the PHP program that created this page. 	 
 
</body>
</html>
	  